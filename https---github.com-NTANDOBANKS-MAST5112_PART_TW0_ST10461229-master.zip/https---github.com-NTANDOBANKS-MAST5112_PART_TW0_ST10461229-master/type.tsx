

export interface DishDetails {
    dish_Name: string;        
    description: string;     
    course: string;           
    price: number;           
  }